# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# i. Swaping numbers

#allowing user to insert number
number1=input("Please enter a number:")
x=int(number1)
number2=input("Please enter another number:")
y= int(number2)

#creating a third memory location

3
tml=x
x=y
y=tml

print(x)
print(y)

