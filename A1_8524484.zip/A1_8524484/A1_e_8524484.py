# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# e. Presenting the name of the user with a greeting

name = input("My name is:")

print ("Hello there,",name,".")
