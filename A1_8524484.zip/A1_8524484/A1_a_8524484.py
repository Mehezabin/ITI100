
# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484


# a. creating a function to computing the sum of 3 numbers


#ask for an input from the user
number1 = input ("Please enter a number:")
x = int(number1)


number2 = input ("Please enter the second number:")
y = int (number2)


number3 = input ("Please enter the third number:")
z = int (number3)


total= x+y+z
print (total)
