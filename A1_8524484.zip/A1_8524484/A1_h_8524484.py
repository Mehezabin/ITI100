# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# h. Calculating the tax on the salary

salary=input("What is your salary?")
x = int(salary)

# a. when salary is within 0-50000
if (x>0) and (x<50000):
    tax = ((x*15)/100)


# b. when salary is greater than 50000
else:
    tax = ((x*25)/100)

print (tax)
