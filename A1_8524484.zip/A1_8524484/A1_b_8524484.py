

# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# b. creating a function to compute the sum of positive integers

number1 = input("Please enter the first number:")
x = int(number1)

while (x<0):
    print ("Wrong Input!")
    number1 = input("Please enter the first number:")
    x = int(number1)
    number2 = input("Please enter the second number:")
    y = int(number2)

    if (y>0):
        number3 = input("Please enter the third number:")
        z = int(number3)



     else:
         print ("Wrong Input!")
 


else:
    print ("Wrong Input!")
          
        
total= x+y+z
print ("SUM:",total,)
print ("The End")
            
            

        


            



    
    
