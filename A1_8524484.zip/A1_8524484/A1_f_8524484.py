# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# f. Printing multiples of 6

n=0
while n<11:
    print(n*6)
    n+=1
    
