# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# j. Printing the max no.

number1=input("Please enter a number:")
x=int(number1)

number2=input("Please enter another number:")
y=int(number2)

higher_value= max(x,y)

print(higher_value)
