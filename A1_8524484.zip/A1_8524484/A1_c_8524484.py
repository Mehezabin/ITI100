# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# c. computing the sum of 3 positive intergers with a counter recording 3 wrong attempts
import sys
import os
counter1=0

while counter1<3:
    counter1+=1
    num1=int(input("Please the first number:"))

    if num1>0:
        break

else:
    print("You entered the wrong input",counter1,"times")
    os._exit(1)

counter2 =0

while counter2<3:
    counter2+=1
    num2=int(input("Please the second number:"))

    if num2>0:
        break

else:
    print("You entered the wrong input",counter2,"times")
    os._exit(1)

counter3 = 0

while counter3<3:
    counter3+=1
    num3=int(input("Please the third number:"))

    if num3>0:
        break

else:
    print("You entered the wrong input",counter3,"times")
    os._exit(1)

    
    

s = num1 + num2 + num3
print(s)

            

    
        


    
