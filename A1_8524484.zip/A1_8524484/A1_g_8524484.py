# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# g. Printing numbers from 1 to 20

n=1
while n<=20:
    print(n)
    n+=1
