# Course:       ITI 1120
# Assignment    1
# Ahamed, Mehezabin
# Student No.:  8524484

# d. converting Temperature from Celcius to Fahrenheit

userinput= input("Please enter temperature in Celcius:")
x=int(userinput)

fahrenheit_temp= ((x*1.8) + 32)

print("The fahrenheit temperature is:",fahrenheit_temp,)
