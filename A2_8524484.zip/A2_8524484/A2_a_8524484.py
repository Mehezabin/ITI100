# Course:       ITI 1120
# Assignment    2
# Ahamed, Mehezabin
# Student No.:  8524484

# a. Printing numbers between the range of 1-1000 that are divisible be 3

#the range is inserted with a constant difference of 3 between each number

for i in range(0,1000,3):
    print (i)

#condition to check the divisibility of each number by 3
if (i%3==0):
    print("These numbers are multiples of 3")

else:
    print ("These aren't multiples of 3")

print ("The End")
