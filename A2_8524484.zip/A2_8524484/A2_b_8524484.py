# Course:       ITI 1120
# Assignment    2
# Ahamed, Mehezabin
# Student No.:  8524484

# b. user decides the range and divisibility criteria


# user enters the arguments for the range function

start = int (input("please enter a value for start: "))
end = int (input("Please enter a value for end: "))
n = int (input("Enter a value for n: "))

# all the numbers within the range is printed

for i in range(start,end,n):
    print (i)

#  condition to check whether the outputs are divisible by n
if (i%n==0):
    print ( "These numbers are divisible by ",n)

else:
    print ("These numbers aren't divisible by ",n)
    
print ("The End")
