# Course:       ITI 1120
# Assignment    2
# Ahamed, Mehezabin
# Student No.:  8524484

# c. printing out the maximum number out of the 10 numbers the user inputs

#user inputs the first number
userinput1 = int (input ("Enter the first number:"))

#the first number is considered the maximum
maximum = userinput1

#the user is asked to input the second number
userinput2 = int (input ("Enter the second number:"))

if (userinput2>maximum): #condition to check which number is greater
    maximum = userinput2    

else:
    maximum = userinput1 #if the second number is not greater,maximum remains the same

#the user is asked to enter the third number
userinput3 = int ( input ("Enter the third number: "))

#condition to see whether the third number is greater
if (userinput3>maximum): 
    maximum = userinput3

#the user is the asked to enter the fourth number
userinput4 = int ( input ( "Enter the fourth number:"))

#conditon check to see whether the maximum value changes
if (userinput4>maximum):
    maximum = userinput4


#the user is the asked to enter the fifth number
userinput5 = int ( input ( "Enter the fifth number:"))

#conditon check to see whether the maximum value changes
if (userinput5>maximum):
    maximum = userinput5


#the user is the asked to enter the sixth number
userinput6 = int ( input ( "Enter the sixth number:"))

#conditon check to see whether the maximum value changes
if (userinput6>maximum):
    maximum = userinput6


#the user is the asked to enter the seventh number
userinput7 = int ( input ( "Enter the seventh number:"))

#conditon check to see whether the maximum value changes
if (userinput7>maximum):
    maximum = userinput7


#the user is the asked to enter the eighth number
userinput8 = int ( input ( "Enter the eighth number:"))

#conditon check to see whether the maximum value changes
if (userinput8>maximum):
    maximum = userinput8


#the user is the asked to enter the ninth number
userinput9 = int ( input ( "Enter the ninth number:"))

#conditon check to see whether the maximum value changes
if (userinput9>maximum):
    maximum = userinput9


#the user is the asked to enter the tenth number
userinput10 = int ( input ( "Enter the the tenth number:"))

#conditon check to see whether the maximum value changes
if (userinput10>maximum):
    maximum = userinput10


print(maximum) #the output is printed
print ("The End.")

