# Course:       ITI 1120
# Assignment    2
# Ahamed, Mehezabin
# Student No.:  8524484

# e. Calculating the standard deviation of the user inputs


#the user inputs five numbers
number1 = int ( input ("Enter the first number: "))

number2 = int ( input ("Enter the second number: "))

number3 = int ( input ("Enter the third number: "))

number4 = int ( input ("Enter the fourth number: "))
number5 = int ( input ("Enter the fifth number: "))

#the average of the numbers are calculated
mean = ( (number1+number2+number3+number4+number5)/ 5)

import math

#add the squared differences
sum_of_squared_differences = ((number1 - mean)**2) + ((number2 - mean)**2) +((number3 - mean)**2) +((number4 - mean)**2) +((number5 - mean)**2)

#compute the variance
variance = (sum_of_squared_differences/5)

#compute the standard deviation by square rooting the variance

standard_deviation = math.sqrt(variance)

#the standard deviation is shown
print ("The Standard Deviation is ", standard_deviation,)
