# Course:       ITI 1120
# Assignment    2
# Ahamed, Mehezabin
# Student No.:  8524484

# d. Printing the average of minimum and maximum

#user inputs the first number
userinput1 = int (input ("Enter the first number:"))

#the user is asked to input the second number
userinput2 = int (input ("Enter the second number:"))

#the user is asked to enter the third number
userinput3 = int ( input ("Enter the third number: "))

#the user is the asked to enter the fourth number
userinput4 = int ( input ( "Enter the fourth number:"))


#the user is the asked to enter the fifth number
userinput5 = int ( input ( "Enter the fifth number:"))

#the user is the asked to enter the sixth number
userinput6 = int ( input ( "Enter the sixth number:"))


#the user is the asked to enter the seventh number
userinput7 = int ( input ( "Enter the seventh number:"))


#the user is the asked to enter the eighth number
userinput8 = int ( input ( "Enter the eighth number:"))


#the user is the asked to enter the ninth number
userinput9 = int ( input ( "Enter the ninth number:"))


#the user is the asked to enter the tenth number
userinput10 = int ( input ( "Enter the the tenth number:"))

#the user inputs are assembled together
lst = [userinput1, userinput2, userinput3, userinput4, userinput5, userinput6, userinput7, userinput8, userinput9, userinput10]


maximum= max (lst) #the maximum is determined from the list
minimun = min (lst) #the minimun is determined ffrom the list

average = ((maximum+minimun)/2) #compute the average of maximum and minimum

print (average) #print the result

print ("the end")


