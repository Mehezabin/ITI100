# Course:       ITI 1120
# Assignment    3
# Ahamed, Mehezabin
# Student No.:  8524484

# c. creating half  a christmas tree

# the drawline method takes the user input to generate the stem of the tree

def drawLine ( c,  n):

#the condition is similar to that used in question b

    # n can't be greater than 50 or less than 0
    
    if (n>50 or n<0):

        # if it is, the character is printed in 50 lines
        for i in range (50):
            print (c*2)

            
    #otherwise the charcter is printed in n lines
    else:

        for i in range (n):
            print (c*2)

#this is responsible for the top part of the tree where the number of character increases  by 1 on each line
def christmasTree (c,n):
    for i in range(n+1):
        print(i*c)

    drawLine(c,n)
