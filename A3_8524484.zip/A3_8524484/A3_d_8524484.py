# Course:       ITI 1120
# Assignment    3
# Ahamed, Mehezabin
# Student No.:  8524484

# d. whether one string is a substring of the other

#the user inputs the variables for stringA and stringB

def substr( stringA,stringB):

#checking whether there are characters of stringA ins stringB
    
    for ch in stringA:
        
        if ch in stringB:
            return True

    #if a is in B, boolean True is the result.
        #otherwise, boolean False
        
    
