# Course:       ITI 1120
# Assignment    3
# Ahamed, Mehezabin
# Student No.:  8524484


# b. drawing a line with character and draw it n times

#creating a function that takes in character and prints n number of times

#user inputs the character and n times
def drawLine ( c,  n):

# n cannot be greater than 50 or less than 0
#if it is, then print the charadcter 50 times
    if (n>50 or n<0):
        for i in range (50):
            print (c, end="")
#if n is not greater than 50 or less than 0, print the character n number of times
    else:

        for i in range (n):
            print (c, end="")
