# Course:       ITI 1120
# Assignment    2
# Ahamed, Mehezabin
# Student No.:  8524484

# a. randomly generating a number

#to deal with random numbers,importing the random library
import random


#user inputs the data for the fuction to get a random number within the range x and y

def getRandomNumber(x,y):
    
    print(random.randrange(x,y))
    
    #returns print(randint(x,y))


